package pl.gov.coi.example.calc;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

/**
 * @author <a href="mailto:krzysztof.suszynski@coi.gov.pl">Krzysztof Suszynski</a>
 * @since 18.11.16
 */
public class AdderTest {
    @Test
    public void testAdd() {
        // given
        Adder adder = new Adder();
        // when
        int result = adder.add(1, 6);

        // then
        assertEquals(7, result);
    }
    @Test
    public void testAdd_less5() {
        // given
        Adder adder = new Adder();
        // when
        int result = adder.add(1, 4);

        // then
        assertEquals(0, result);
    }

}
