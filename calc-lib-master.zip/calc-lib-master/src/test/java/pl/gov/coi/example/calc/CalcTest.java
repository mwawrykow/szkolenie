package pl.gov.coi.example.calc;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.junit.MockitoJUnit;
import org.mockito.junit.MockitoRule;
import org.mockito.stubbing.Answer;

import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Mockito.when;

/**
 * @author <a href="mailto:krzysztof.suszynski@coi.gov.pl">Krzysztof Suszynski</a>
 * @since 17.11.16
 */
public class CalcTest {

    @Rule
    public MockitoRule mockitoRule = MockitoJUnit.rule();

    @Mock
    private Adder adder;

    @Before
    public void before() {
        when(adder.add(anyInt(), anyInt())).thenAnswer(new Answer<Integer>() {
            public Integer answer(InvocationOnMock invocation) throws Throwable {
                int a = invocation.getArgumentAt(0, Integer.class);
                int b = invocation.getArgumentAt(1, Integer.class);
                return a + b;
            }
        });
    }

    @Test
    public void testAdd() {
        // given
        int a = 5;
        int b = 4;
        Calc calc = new Calc(adder);

        // when
        int result = calc.add(a, b);

        // then
        assertEquals(9, result);
    }

    @Test
    public void testAdd_AMoreThen6() {
        // given
        int a = 7;
        int b = 4;
        Calc calc = new Calc(adder);

        // when
        int result = calc.add(a, b);

        // then
        assertEquals(-10, result);
    }

}
