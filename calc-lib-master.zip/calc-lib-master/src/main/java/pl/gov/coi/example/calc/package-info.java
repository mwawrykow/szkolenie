/**
 * @author <a href="mailto:krzysztof.suszynski@coi.gov.pl">Krzysztof Suszynski</a>
 * @since 18.11.16
 */
@ParametersAreNonnullByDefault
package pl.gov.coi.example.calc;

import javax.annotation.ParametersAreNonnullByDefault;
