package pl.gov.coi.example.calc;

import static pl.wavesoftware.eid.utils.EidPreconditions.checkNotNull;

/**
 * @author <a href="mailto:krzysztof.suszynski@coi.gov.pl">Krzysztof Suszynski</a>
 * @since 17.11.16
 */
public class Adder {

    public int add(int a, Integer b) {
        checkNotNull(b, "20161118:085159");
        if (b < 5 && b > 3) {
            return  0;
        }
        return a + b;
    }
}
